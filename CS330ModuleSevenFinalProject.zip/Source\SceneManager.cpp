///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	// no textures have been loaded into memory yet
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the image textures from disk before any shapes are drawn
	LoadSceneTextures();
	// define how each surface reacts to light (Phong materials)
	DefineObjectMaterials();
	// add and configure the light sources that illuminate the scene
	SetupSceneLights();

	// Only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene.  The house replica reuses
	// these primitives many times through transformations.
	m_basicMeshes->LoadPlaneMesh();     // lawn and driveway surfaces
	m_basicMeshes->LoadBoxMesh();       // house body, garage, door, windows
	m_basicMeshes->LoadPrismMesh();     // triangular gable roofs
	m_basicMeshes->LoadCylinderMesh();  // porch posts and tree trunk
	m_basicMeshes->LoadSphereMesh();    // tree foliage
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads every image texture used by the scene into OpenGL
 *  memory and binds them to texture slots.  Each texture is
 *  tagged with a short name so the render helpers can request
 *  it by tag.  The images are small, tileable JPG files that
 *  live in the "textures" folder next to the executable.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// house surfaces (palette matched to the reference photo)
	CreateGLTexture("textures/siding.jpg", "siding");      // tan lap siding - main walls
	CreateGLTexture("textures/stone.jpg", "stone");        // cultured stone veneer accent
	CreateGLTexture("textures/shingles.jpg", "shingles");  // weathered gray roof shingles
	CreateGLTexture("textures/door.jpg", "door");          // dark front door with wreath
	CreateGLTexture("textures/garagedoor.jpg", "garage");  // white paneled garage door
	CreateGLTexture("textures/glass.jpg", "glass");        // windows
	CreateGLTexture("textures/concrete.jpg", "concrete");  // driveway, porch

	// surrounding scenery
	CreateGLTexture("textures/grass.jpg", "grass");        // lawn
	CreateGLTexture("textures/bark.jpg", "bark");          // tree trunk
	CreateGLTexture("textures/leaves.jpg", "leaves");      // tree canopy

	// bind all of the loaded textures to their memory slots
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the Phong material properties for each kind of
 *  surface in the scene.  The material controls how strongly
 *  a surface reflects diffuse and specular light and how
 *  focused its highlight is (shininess).  Each material is
 *  tagged so the render helpers can select it per shape.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// start with a clean list
	m_objectMaterials.clear();

	// tan lap siding - mostly matte with a faint sheen
	OBJECT_MATERIAL sidingMaterial;
	sidingMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	sidingMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	sidingMaterial.shininess = 8.0f;
	sidingMaterial.tag = "siding";
	m_objectMaterials.push_back(sidingMaterial);

	// cultured stone - rough, almost no highlight
	OBJECT_MATERIAL stoneMaterial;
	stoneMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	stoneMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	stoneMaterial.shininess = 4.0f;
	stoneMaterial.tag = "stone";
	m_objectMaterials.push_back(stoneMaterial);

	// asphalt shingles - matte with a slight sheen when wet-looking
	OBJECT_MATERIAL roofMaterial;
	roofMaterial.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	roofMaterial.specularColor = glm::vec3(0.14f, 0.14f, 0.14f);
	roofMaterial.shininess = 12.0f;
	roofMaterial.tag = "roof";
	m_objectMaterials.push_back(roofMaterial);

	// window glass - shiny with a tight, bright highlight
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.95f);
	glassMaterial.specularColor = glm::vec3(0.90f, 0.90f, 0.90f);
	glassMaterial.shininess = 90.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// painted doors / trim - semi-gloss paint
	OBJECT_MATERIAL paintMaterial;
	paintMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	paintMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	paintMaterial.shininess = 32.0f;
	paintMaterial.tag = "paint";
	m_objectMaterials.push_back(paintMaterial);

	// concrete - rough with just a little brightness
	OBJECT_MATERIAL concreteMaterial;
	concreteMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	concreteMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	concreteMaterial.shininess = 6.0f;
	concreteMaterial.tag = "concrete";
	m_objectMaterials.push_back(concreteMaterial);

	// organic surfaces (grass, bark, leaves) - matte, no highlight
	OBJECT_MATERIAL organicMaterial;
	organicMaterial.diffuseColor = glm::vec3(0.95f, 0.95f, 0.95f);
	organicMaterial.specularColor = glm::vec3(0.03f, 0.03f, 0.03f);
	organicMaterial.shininess = 2.0f;
	organicMaterial.tag = "organic";
	m_objectMaterials.push_back(organicMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Adds the light sources for this outdoor daytime scene and
 *  switches lighting on in the shader.  A bright directional
 *  "sun" provides the main diffuse and specular light from the
 *  upper front, and a softer point light near the camera fills
 *  in the front faces.  A generous ambient term guarantees
 *  that no surface is ever left in complete shadow.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// turn the Phong lighting model on in the fragment shader
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// --- main sunlight: a directional light from the upper front ---
	// A slightly warm white sun provides the dominant diffuse and
	// specular lighting.  All three Phong components are supplied.
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -0.6f, -0.7f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.30f, 0.30f, 0.32f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.80f, 0.77f, 0.70f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.45f, 0.45f, 0.45f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// --- warm point light near the camera (a COLORED light) ---
	// This golden point light warms the front facade and gives the
	// scene a sunny feel; it is clearly colored (warm amber).
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 8.0f, 16.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.04f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.55f, 0.42f, 0.22f); // warm amber
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.40f, 0.34f, 0.22f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// --- cool point light on the left (a second COLORED light) ---
	// A soft sky-blue fill lights the garage side so nothing there
	// goes dark as the camera orbits the scene.
	m_pShaderManager->setVec3Value("pointLights[1].position", -10.0f, 7.0f, 6.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.03f, 0.04f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.22f, 0.28f, 0.40f); // cool blue
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.12f, 0.14f, 0.20f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// the remaining point lights and the spotlight stay disabled
	m_pShaderManager->setBoolValue("pointLights[2].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// The complex object from the 2D reference image is a
	// two-story suburban house with an attached garage, a
	// covered front porch, and a large tree to the side.
	// Each part is drawn by its own helper so the overall
	// scene stays readable and the transforms stay grouped
	// with the shape they belong to.  The house is oriented
	// so its front faces +Z, toward the default camera.
	RenderGround();          // grass and driveway
	RenderMainHouse();       // two-story body + main gable roof
	RenderFrontWing();       // projecting stone gable section on the right
	RenderGarage();          // garage wing + roof + door
	RenderPorch();           // covered entry porch
	RenderDoorAndWindows();  // front door and windows
	RenderTree();            // large tree beside the house
}

/***********************************************************
 *  RenderGround()
 *
 *  Draws the flat surfaces the house sits on: a green grass
 *  lawn and a light gray concrete driveway leading up to the
 *  garage, matching the foreground of the reference image.
 ***********************************************************/
void SceneManager::RenderGround()
{
	// grass lawn - a wide, flat plane centered on the origin.
	// The grass texture is TILED many times across the large
	// plane so each blade stays crisp instead of being stretched.
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 14.0f),  // scale: large flat area
		0.0f, 0.0f, 0.0f,               // no rotation needed
		glm::vec3(0.0f, 0.0f, 0.0f));   // sits at ground level
	SetShaderTexture("grass");
	SetTextureUVScale(10.0f, 7.0f);     // tile the grass across the lawn
	SetShaderMaterial("organic");       // matte lawn, reflects soft light
	m_basicMeshes->DrawPlaneMesh();

	// concrete driveway - a narrower plane in front of the
	// garage, raised very slightly so it draws above the grass
	SetTransformations(
		glm::vec3(1.9f, 1.0f, 6.0f),    // scale: long, narrow strip
		0.0f, 0.0f, 0.0f,
		glm::vec3(-3.25f, 0.01f, 9.5f)); // aligned with the garage
	SetShaderTexture("concrete");
	SetTextureUVScale(2.0f, 6.0f);      // tile along the driveway length
	SetShaderMaterial("concrete");      // rough surface with a little brightness
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderMainHouse()
 *
 *  Draws the two-story main body of the house as a scaled box
 *  and tops it with a triangular prism used as a gable roof.
 *  The prism is rotated so its ridge runs left-to-right and
 *  the sloped faces are seen from the front, like the image.
 ***********************************************************/
void SceneManager::RenderMainHouse()
{
	// two-story main body (brick/siding colored box)
	SetTransformations(
		glm::vec3(6.0f, 5.0f, 5.0f),    // width, height (2 stories), depth
		0.0f, 0.0f, 0.0f,
		glm::vec3(1.5f, 2.5f, 0.0f));   // centered so base rests on y = 0
	// tan lap-siding texture, tiled so the boards stay realistic
	SetShaderTexture("siding");
	SetTextureUVScale(4.0f, 5.0f);
	SetShaderMaterial("siding");
	m_basicMeshes->DrawBoxMesh();

	// main gable roof (triangular prism)
	// XrotationDegrees = -90 tips the prism onto its side and
	// YrotationDegrees = 90 turns the ridge to run left-to-right.
	// NOTE: scale is applied before the rotations, so the scale
	// values are given in the prism's LOCAL axes.  After the
	// rotations they map to the world as:
	//   local X -> front-to-back depth, local Y -> ridge length
	//   (left to right), local Z -> roof height.
	SetTransformations(
		glm::vec3(5.0f, 6.0f, 2.5f),    // depth, ridge length, height
		-90.0f, 90.0f, 0.0f,
		glm::vec3(1.5f, 6.25f, 0.0f));  // seated on top of the body
	// shingle texture, tiled across the large roof surface
	SetShaderTexture("shingles");
	SetTextureUVScale(5.0f, 3.0f);
	SetShaderMaterial("roof");
	m_basicMeshes->DrawPrismMesh();
}

/***********************************************************
 *  RenderFrontWing()
 *
 *  Draws the two-story section on the right of the house that
 *  projects toward the street and is capped by a front-facing
 *  gable, exactly as in the reference photo.  It is built from
 *  a stone-veneer lower box, a tan-siding upper box, and a
 *  triangular prism roof whose gable end faces the camera.
 ***********************************************************/
void SceneManager::RenderFrontWing()
{
	// lower level - cultured stone veneer, projecting forward (+Z)
	SetTransformations(
		glm::vec3(2.8f, 2.5f, 2.2f),    // width, one-story height, depth
		0.0f, 0.0f, 0.0f,
		glm::vec3(3.3f, 1.25f, 2.1f));  // right side, pushed toward the street
	SetShaderTexture("stone");
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderMaterial("stone");
	m_basicMeshes->DrawBoxMesh();

	// upper level - tan siding, stacked on top of the stone level
	SetTransformations(
		glm::vec3(2.8f, 2.5f, 2.2f),    // same footprint, second story
		0.0f, 0.0f, 0.0f,
		glm::vec3(3.3f, 3.75f, 2.1f));
	SetShaderTexture("siding");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderMaterial("siding");
	m_basicMeshes->DrawBoxMesh();

	// front-facing gable roof (prism).  XrotationDegrees = -90 lays
	// the prism down so the triangular gable end points at the
	// camera.  Scale maps as: local X -> width, local Y -> depth
	// (front to back), local Z -> roof height.
	SetTransformations(
		glm::vec3(2.8f, 2.2f, 1.6f),    // width, depth, height
		-90.0f, 0.0f, 0.0f,
		glm::vec3(3.3f, 5.8f, 2.1f));   // seated on top of the wing
	SetShaderTexture("shingles");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderMaterial("roof");
	m_basicMeshes->DrawPrismMesh();
}

/***********************************************************
 *  RenderGarage()
 *
 *  Draws the single-story attached garage to the left of the
 *  main house.  It uses a box for the walls, a prism for a
 *  front-facing gable roof, and a light box for the garage
 *  door, just as shown in the 2D reference image.
 ***********************************************************/
void SceneManager::RenderGarage()
{
	// garage walls (single story box, shorter than the house)
	SetTransformations(
		glm::vec3(3.5f, 3.0f, 4.0f),    // width, height, depth
		0.0f, 0.0f, 0.0f,
		glm::vec3(-3.25f, 1.5f, 0.5f)); // to the left, front flush at z = 2.5
	// lap-siding texture, tiled so the boards read at the right scale
	SetShaderTexture("siding");
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("siding");
	m_basicMeshes->DrawBoxMesh();

	// garage gable roof (prism)
	// Only XrotationDegrees = -90 is used, so the ridge runs
	// front-to-back and the triangular gable faces the street.
	// Scale is in local axes (applied before rotation) and maps
	// to the world as: local X -> width (left to right),
	// local Y -> front-to-back depth, local Z -> roof height.
	SetTransformations(
		glm::vec3(3.5f, 4.0f, 1.5f),    // width, depth, height
		-90.0f, 0.0f, 0.0f,
		glm::vec3(-3.25f, 3.75f, 0.5f)); // seated on top of garage walls
	// same shingle texture as the main roof keeps the roofs cohesive
	SetShaderTexture("shingles");
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderMaterial("roof");
	m_basicMeshes->DrawPrismMesh();

	// garage door (thin paneled box on the front face)
	SetTransformations(
		glm::vec3(2.8f, 2.2f, 0.12f),   // wide, tall, very thin
		0.0f, 0.0f, 0.0f,
		glm::vec3(-3.25f, 1.1f, 2.56f)); // pressed against the front wall
	// paneled garage-door texture (single tile = one full door)
	SetShaderTexture("garage");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("paint");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderPorch()
 *
 *  Draws the covered front entry porch: two cylindrical
 *  support posts, a thin box floor/step, and a thin box roof
 *  resting on the posts, matching the porch in the image.
 ***********************************************************/
void SceneManager::RenderPorch()
{
	// porch floor / step (thin box in front of the entry)
	SetTransformations(
		glm::vec3(3.4f, 0.2f, 1.6f),    // wide, flat slab
		0.0f, 0.0f, 0.0f,
		glm::vec3(1.5f, 0.1f, 3.1f));   // just in front of the house
	// concrete texture ties the porch slab to the driveway material
	SetShaderTexture("concrete");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("concrete");
	m_basicMeshes->DrawBoxMesh();

	// two porch posts (cylinders stand upright from y = 0 to y = 1).
	// The posts are painted a solid white, so SetShaderColor is used
	// here (it also turns texturing off for these draws).  A paint
	// material still lets them catch the light.
	SetShaderColor(0.95f, 0.95f, 0.93f, 1.0f); // white posts
	SetShaderMaterial("paint");
	SetTransformations(
		glm::vec3(0.14f, 2.4f, 0.14f),  // thin and tall
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.2f, 0.2f, 3.6f));   // left post
	m_basicMeshes->DrawCylinderMesh();

	SetTransformations(
		glm::vec3(0.14f, 2.4f, 0.14f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(2.8f, 0.2f, 3.6f));   // right post
	m_basicMeshes->DrawCylinderMesh();

	// porch roof (thin box resting on top of the posts)
	SetTransformations(
		glm::vec3(3.4f, 0.25f, 1.8f),   // covers the entry area
		0.0f, 0.0f, 0.0f,
		glm::vec3(1.5f, 2.6f, 3.4f));
	// shingle texture matches the main and garage roofs
	SetShaderTexture("shingles");
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderMaterial("roof");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderDoorAndWindows()
 *
 *  Draws the front entry door and several window openings as
 *  thin boxes pressed against the front wall of the house,
 *  giving the facade the detail seen in the reference image.
 ***********************************************************/
void SceneManager::RenderDoorAndWindows()
{
	// front entry door (dark, with a wreath), centered under the porch
	SetTransformations(
		glm::vec3(1.0f, 2.1f, 0.12f),   // tall, narrow, thin
		0.0f, 0.0f, 0.0f,
		glm::vec3(1.5f, 1.05f, 2.56f)); // on the main front wall (z = 2.5)
	SetShaderTexture("door");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("paint");
	m_basicMeshes->DrawBoxMesh();

	// upper-floor windows on the main siding wall (front wall at z = 2.5)
	DrawWindowWithShutters(0.0f, 3.6f, 2.5f);
	DrawWindowWithShutters(1.5f, 3.6f, 2.5f);

	// windows on the projecting stone wing (front wall at z = 3.2)
	DrawWindowWithShutters(3.3f, 3.7f, 3.2f);  // upper floor
	DrawWindowWithShutters(3.3f, 1.5f, 3.2f);  // lower floor
}

/***********************************************************
 *  DrawWindowWithShutters()
 *
 *  Draws one framed-glass window flanked by a black shutter on
 *  each side.  Reusing this helper keeps every window on the
 *  house consistent and the calling code short and readable.
 *  (x, y) is the window center; wallFrontZ is the front plane
 *  of the wall the window sits on.
 ***********************************************************/
void SceneManager::DrawWindowWithShutters(float x, float y, float wallFrontZ)
{
	// glazed window pane, pressed slightly in front of the wall
	SetTransformations(
		glm::vec3(0.9f, 1.3f, 0.08f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x, y, wallFrontZ + 0.06f));
	SetShaderTexture("glass");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("glass");           // shiny, picks up a bright highlight
	m_basicMeshes->DrawBoxMesh();

	// black shutters sit flat on the wall on either side of the pane
	SetShaderColor(0.07f, 0.07f, 0.09f, 1.0f);
	SetShaderMaterial("paint");
	SetTransformations(
		glm::vec3(0.22f, 1.3f, 0.05f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x - 0.58f, y, wallFrontZ + 0.03f)); // left shutter
	m_basicMeshes->DrawBoxMesh();

	SetTransformations(
		glm::vec3(0.22f, 1.3f, 0.05f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(x + 0.58f, y, wallFrontZ + 0.03f)); // right shutter
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderTree()
 *
 *  Draws the large tree standing to the right of the house
 *  using a cylinder for the trunk and a sphere for the leafy
 *  canopy, echoing the prominent tree in the 2D image.
 ***********************************************************/
void SceneManager::RenderTree()
{
	// trunk (upright cylinder rising from the ground)
	SetTransformations(
		glm::vec3(0.35f, 4.0f, 0.35f),  // slim and tall
		0.0f, 0.0f, 0.0f,
		glm::vec3(8.0f, 0.0f, 2.0f));   // right of the house
	// bark texture, tiled vertically up the trunk
	SetShaderTexture("bark");
	SetTextureUVScale(1.0f, 3.0f);
	SetShaderMaterial("organic");
	m_basicMeshes->DrawCylinderMesh();

	// canopy (sphere of leaves seated on top of the trunk)
	SetTransformations(
		glm::vec3(2.6f, 2.6f, 2.6f),    // full, round canopy
		0.0f, 0.0f, 0.0f,
		glm::vec3(8.0f, 4.5f, 2.0f));   // above the trunk
	// leaf texture, tiled around the canopy for dense foliage
	SetShaderTexture("leaves");
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("organic");
	m_basicMeshes->DrawSphereMesh();
}
