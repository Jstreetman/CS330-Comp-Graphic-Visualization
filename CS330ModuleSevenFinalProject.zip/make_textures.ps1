# ============================================================================
# make_textures.ps1
# Generates 1024x1024, tileable, self-authored texture images for the scene.
# The images are created from scratch (no third-party assets), so they are
# royalty-free and safe to distribute, and they meet the final project's
# 1024x1024 minimum resolution requirement.  The palette is matched to the
# reference photo: light tan lap siding, gray/tan cultured stone, weathered
# gray shingles, a dark wreathed front door, a white paneled garage door,
# framed glass, concrete, grass, bark, and leaves.
# Output: 1024x1024 JPG files in the "textures" folder.
# ============================================================================
Add-Type -AssemblyName System.Drawing

$outDir = Join-Path $PSScriptRoot "textures"
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }

$size = 1024
$rng  = New-Object System.Random 2026

function New-Bitmap { param($w,$h) return New-Object System.Drawing.Bitmap $w,$h }
function Save-Jpg { param($bmp,$name)
    $path = Join-Path $outDir $name
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Jpeg)
    $bmp.Dispose()
    Write-Host "wrote $name"
}
function C { param($r,$g,$b)
    $r=[Math]::Max(0,[Math]::Min(255,[int]$r))
    $g=[Math]::Max(0,[Math]::Min(255,[int]$g))
    $b=[Math]::Max(0,[Math]::Min(255,[int]$b))
    return [System.Drawing.Color]::FromArgb($r,$g,$b)
}

# ---------------------------------------------------------------- SIDING (light tan lap)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 210 204 190))                    # warm light greige
$boardH = 44
for ($y = 0; $y -lt $size; $y += $boardH) {
    $shadow = New-Object System.Drawing.SolidBrush (C 188 182 167)
    $g.FillRectangle($shadow, 0, $y, $size, 6)   # shadow line under each lap board
    $shadow.Dispose()
    $hi = New-Object System.Drawing.SolidBrush (C 220 214 200)
    $g.FillRectangle($hi, 0, $y + 6, $size, 4)   # subtle highlight
    $hi.Dispose()
}
$g.Dispose(); Save-Jpg $bmp "siding.jpg"

# ---------------------------------------------------------------- STONE (cultured stone veneer)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 196 192 184))                    # light mortar
$stoneH = 120
$y = 0
while ($y -lt $size) {
    $x = -($rng.Next(0, 160))
    while ($x -lt $size) {
        $w = $rng.Next(130, 240)
        $h = $stoneH - $rng.Next(8, 28)
        if ($rng.Next(0, 2) -eq 0) {
            $base = $rng.Next(120, 165); $stone = C $base ($base - 6) ($base - 14)   # tan
        } else {
            $base = $rng.Next(110, 160); $stone = C ($base - 8) ($base - 4) $base    # gray
        }
        $br = New-Object System.Drawing.SolidBrush $stone
        $g.FillRectangle($br, $x, $y, $w - 12, $h)
        $br.Dispose()
        $x += $w
    }
    $y += $stoneH
}
$g.Dispose(); Save-Jpg $bmp "stone.jpg"

# ---------------------------------------------------------------- SHINGLES (weathered gray roof)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 104 101 97))
$rowH = 104; $tabW = 88; $r = 0
for ($y = 0; $y -lt $size; $y += $rowH) {
    $off = ($r % 2) * ($tabW / 2)
    for ($x = -$tabW; $x -lt $size; $x += $tabW) {
        $v = $rng.Next(-14, 12)
        $br = New-Object System.Drawing.SolidBrush (C (104 + $v) (101 + $v) (97 + $v))
        $g.FillRectangle($br, [int]($x + $off), [int]$y, $tabW - 8, $rowH - 12)
        $br.Dispose()
    }
    $pen = New-Object System.Drawing.Pen (C 68 66 64), 8
    $g.DrawLine($pen, 0, $y, $size, $y)   # shadow between shingle rows
    $pen.Dispose()
    $r++
}
$g.Dispose(); Save-Jpg $bmp "shingles.jpg"

# ---------------------------------------------------------------- DOOR (dark, with wreath)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear((C 34 34 40))                       # near-black front door
$panelPen = New-Object System.Drawing.Pen (C 60 60 68), 16
$g.DrawRectangle($panelPen, 184, 80, 656, 344)    # upper panel
$g.DrawRectangle($panelPen, 184, 560, 656, 344)   # lower panel
$panelPen.Dispose()
# decorative green wreath on the upper half of the door
$wreathPen = New-Object System.Drawing.Pen (C 46 92 46), 56
$g.DrawEllipse($wreathPen, 392, 192, 240, 240)
$wreathPen.Dispose()
$g.Dispose(); Save-Jpg $bmp "door.jpg"

# ---------------------------------------------------------------- GARAGE DOOR (white paneled)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 232 232 228))
$pen = New-Object System.Drawing.Pen (C 176 176 170), 12
for ($r = 0; $r -lt 4; $r++) {
    for ($c = 0; $c -lt 4; $c++) {
        $g.DrawRectangle($pen, 32 + $c * 248, 32 + $r * 248, 216, 216)   # raised panels grid
    }
}
$pen.Dispose()
$g.Dispose(); Save-Jpg $bmp "garagedoor.jpg"

# ---------------------------------------------------------------- GLASS (window)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 150 170 188))                    # light sky-reflecting glass
$refl = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point 0,0), (New-Object System.Drawing.Point $size,$size), (C 180 198 214), (C 120 142 162)
$g.FillRectangle($refl, 0, 0, $size, $size)
$refl.Dispose()
$frame = New-Object System.Drawing.Pen (C 240 240 236), 64
$g.DrawRectangle($frame, 32, 32, $size - 64, $size - 64)   # white window frame
$frame.Dispose()
$muntin = New-Object System.Drawing.Pen (C 240 240 236), 32
$g.DrawLine($muntin, $size/2, 0, $size/2, $size)           # vertical divider
$muntin.Dispose()
$g.Dispose(); Save-Jpg $bmp "glass.jpg"

# ---------------------------------------------------------------- NOISE HELPER (fast scatter)
# Fills a base color then scatters many small shaded rectangles.  This is far
# faster than per-pixel writes at 1024x1024 and still reads as organic noise.
function Make-Noise { param($name,$br,$bg,$bb,$spread,$count)
    $bmp = New-Bitmap $size $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear((C $br $bg $bb))
    for ($i = 0; $i -lt $count; $i++) {
        $v = $rng.Next(-$spread, $spread)
        $x = $rng.Next(0, $size)
        $y = $rng.Next(0, $size)
        $s = $rng.Next(4, 9)
        $brush = New-Object System.Drawing.SolidBrush (C ($br + $v) ($bg + $v) ($bb + $v))
        $g.FillRectangle($brush, $x, $y, $s, $s)
        $brush.Dispose()
    }
    $g.Dispose()
    Save-Jpg $bmp $name
}

Make-Noise "grass.jpg"    78 124 52   30 60000   # lawn
Make-Noise "concrete.jpg" 180 178 172 20 55000   # driveway / porch
Make-Noise "leaves.jpg"   52 104 46   34 60000   # tree canopy

# ---------------------------------------------------------------- BARK (tree trunk)
$bmp = New-Bitmap $size $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear((C 86 60 40))
for ($x = 0; $x -lt $size; $x += 1) {
    if ($rng.Next(0, 3) -eq 0) {
        $v = $rng.Next(-22, 10)
        $pen = New-Object System.Drawing.Pen (C (86 + $v) (60 + $v) (40 + $v)), 1
        $g.DrawLine($pen, $x, 0, $x + $rng.Next(-24, 24), $size)   # rough vertical bark grain
        $pen.Dispose()
    }
}
$g.Dispose(); Save-Jpg $bmp "bark.jpg"

Write-Host "DONE"
